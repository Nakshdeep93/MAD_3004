//
//  DataHelper.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class DataHelper{
    var ProductList = [Int : Product]()
    
    init(){
        self.loadProductData()
    }
    
    func loadProductData(){
        ProductList = [:]
        
        let epson = Product(productID: 101, productName: "projector", manufacturer: "epson", unitPrice: 1000.1, category: ProductCategory.Appliances)
        ProductList[epson.ProductID!] = epson
        
        let handcream = Product(productID: 101, productName: "Handcream", manufacturer: "Glysomed", unitPrice: 12.23, category: ProductCategory.Health)
        
        ProductList[handcream.ProductID!] = handcream
        
        
        
        let flask = Product(productID: 102, productName: "Flask", manufacturer: "Contigo", unitPrice: 20, category: ProductCategory.Appliances)
        
        ProductList[flask.ProductID!] = flask
        
    
        
    }
    func displayProducts(){
        for( _ , value) in self.ProductList.sorted(by: {$0.key < $1.key}){
            
            print(value.displayData())
        }
    }
}






