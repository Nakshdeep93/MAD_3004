//
//  main.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-20.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
/*
print("Hello, World!")

var Santosh = Customer()
Santosh.customerID = "C101"
//Santosh.customerName = "Santosh"
print(Santosh.displayData())

var Param = Customer(customerID: "C102", customerName: "Paramjeet", email: "param@mad.com", address: "114 Michigan Ave. Brampton", creditCardInfo: "4520-0100-1234-5678", shippingInfo: "Ship to lambton college between 08:00 AM to 12:00 PM")
print(Param.displayData())

var Saloni = Customer()
Saloni.registerUser()
print(Saloni.displayData())

Saloni.CustomerName = "Sallu"
Saloni.ShippingInfo = "Deliver between 10AM to 12PM"
print(Saloni.displayData())

Santosh.CustomerName = "Santosh"
Santosh.Email = "Santosh@mad.com"
Santosh.Address = "54 Marjary Ave. DownTown. Toronto"
Santosh.CreditCardInfo = "4520-0100-6543-8976"
Santosh.ShippingInfo = "Deliver at Papa John's at 03PM"
print(Santosh.displayData())




var epson = Product(productID: 101, productName: "projector", manufecturer: "epson", unitPrice: 1000.1, category: ProductCategory.Appliances)

print(epson.displayData())
var handcream = Product()
handcream.newProduct()
print(handcream.displayData())
*/ 
var dataHelper = DataHelper()
dataHelper.displayProducts()










