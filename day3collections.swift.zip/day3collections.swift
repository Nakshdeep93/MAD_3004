import Foundation

print("Hello World")
var friends : [String]
friends = ["Ishav","Param","naksh","manjot","harman"]
print("Friends : \(friends)")

for frnd in friends{
    
    print("Friends : \(frnd)")
}

//var len = friends.count
//for itr in 0..<friends.count{

   // print("Friend \(friends[itr])")

for(index, value) in
friends.enumerated() {
    print("index : \(index) value :\(index) value :\(value)")
}
    
for frnd in friends[2...]{
    print("Friends : \(frnd)")
}
for frnd in friends[...2]
{
     print("Friends : \(frnd)")
}

var numbers = Array(repeating: 1, count: 4)

print("Numbers : \(numbers)")

numbers[2] = 100
print("numbers : \(numbers)")

var more = Array(repeating:0,count: 3)
print("more : \(more)")

var all = numbers + more
print("all :\(all)")

for(index, value) in
all.enumerated() {
    print("index : \(index) value :\(index) value :\(value)")
}

print("all[9] \(all[3])")

var grocery = ["eggs","milk"]
grocery.append("rice")
grocery += ["Juice","sher aata"]
grocery[1...3] = ["butter","snacks","ice cream"]
grocery.insert("veggies", at: 4)
grocery.remove(at: 3)
grocery.removeLast()
print("Grocery :\(grocery)")

grocery.removeAll()
if grocery.isEmpty{
    print("no grocery to shop")
}else{
    print("grocery list : \(grocery)")
}

var dynamic = [Any]()
dynamic.append ("JK")
dynamic.append (4567)
dynamic.append (23.34)
dynamic.append("F")
print("Dynamic: \(dynamic)")

//SETS:

var languages = Set<String>()
languages.insert("Punjabi")
languages.insert("hindi")
languages.insert("gujrati")
languages.insert("english")
languages.insert("portuguese")
languages.remove("English")


if languages.isEmpty{
    print("no languages")
}else{
    print("\(languages.count) languages : \(languages)")
}

for lang in languages.sorted(){
    print("language : \(lang)")
}

let motherTongue : Set = ["punjabi","gujrati","telgue","portuguese"]

print("mothetTongue : \(motherTongue)")

print("Union : \(languages.union(motherTongue).sorted())")
print("Intersection : \(languages.intersection(motherTongue).sorted())")
print("subtracting :\(languages.subtracting(motherTongue).sorted())")
print("SymmertricDifference :\(languages.symmetricDifference(motherTongue).sorted())")

//DICTIONARY
var namesofInt = [Int : String]()
namesofInt[20] = "Twenty"
print("values of key 20 \(namesofInt[20])")
namesofInt[2] = "two"
print("values of key 2 \(namesofInt[2])")
print("namesofInt contains \(namesofInt.count) items")

namesofInt = [:]
if namesofInt.isEmpty{
    print("No item in the dictionary")
    }

    var HTTPErrorCode : [Int : String] = [400 : "Bad Request", 402 : "Payment Required", 404 :"Not Found", 406 : "Not Acceptable"]
    HTTPErrorCode[405] = "Method not allowed"

    let old402 = HTTPErrorCode.updateValue("Reserved for future use", forKey : 402)

    print("Error code list: \(HTTPErrorCode)")

    let errMSG406 = HTTPErrorCode[406]
    print("Error message for 406 \(errMSG406)")

    if    let errMSG406 = HTTPErrorCode[406]
    {
    print("Error message for 406 \(errMSG406)")
   }
else{
        print("no error code 403 is available")
    }
    HTTPErrorCode[406] = nil
    print ("Error code list : \(HTTPErrorCode)")

 if let removedValue = HTTPErrorCode.removeValue(forKey : 404)
    {
        print("removed value : \(removedValue)")
    }
        else
        {
            print("error code 404 is not available")
            }

            for errorMsg in HTTPErrorCode.values{
                print("error message : \(errorMsg)")
            }

                for (errorCode, errorMsg) in HTTPErrorCode{
                    print("error code : \(errorCode)--- Error msg :\(errorMsg)")
                }
                let errorCodeList = HTTPErrorCode.keys
                print("error code list : \(errorCodeList)")

                var flight = [String : AnyObject]()
                flight["number"] = "AC043" as AnyObject
                flight["duration"] = 14 as AnyObject
                flight["cost"] = 1600.23 as AnyObject
                print("flight \(flight)")

    






