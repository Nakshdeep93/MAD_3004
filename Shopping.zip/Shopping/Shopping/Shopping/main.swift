//
//  main.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var Naksh = Customer()
Naksh.customerID = "C101"
//Naksh.customerName = "naksh"
//Naksh.displayData()
print(Naksh.display())

var param = Customer(customerID: "C012", customerName: "Paramjit", address: "Brampton", email: "param@mad.com", creditCardInfo: "4368-6678-6678-7890",shippingInfo: "ship to lambton college")
print(param.display())
var manjot = Customer()
manjot.registerUser()
print(manjot.display())

manjot.CustomerName = "jot"
//manjot.shippingInfo = "Deliver between 10AM TO 12PM "
manjot.Email = "manjot@gmail.com"
manjot.Address = "brampton"
manjot.CreditCardInfo = "242563675857"
manjot.ShippingInfo = "lambton college"
print(manjot.display())
