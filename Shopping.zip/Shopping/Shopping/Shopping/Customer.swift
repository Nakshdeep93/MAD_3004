//
//  Customer.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class Customer{
    var customerID : String?
    private var customerName : String?
    private var address : String?
    private var email : String?
    private var creditCardInfo : String?
    private var shippingInfo : String?
    
    
    //stored property
    
    var CustomerName : String?
    {
        get{
            return self.customerName
        }
        set{
            self.customerName = newValue
        
        }
    }
    var Email : String?{
        get {
            return self.email
    }
    set{
     self.email = newValue
    
    }
    }
        var Address : String?{
        get {
        return self.address
        }
        set{
        self.address = newValue
        
        }
    }
        var CreditCardInfo : String?{
        get {
        return self.creditCardInfo
        }
        set{
        self.creditCardInfo = newValue
        
            }}
        var ShippingInfo : String?{
        get {
        return self.shippingInfo
        }
        set{
        self.shippingInfo = newValue
        
            }}
        
        //default initailzer / constructor
    init(){
        self.customerID = ""
        self.customerName = ""
        self.address = ""
        self.email = ""
        self.creditCardInfo = ""
        self.shippingInfo = ""
        
    }
    //parametrized initializer
    init(customerID: String, customerName:
        String, address: String, email: String, creditCardInfo: String,shippingInfo: String){
        
        self.customerID = customerID
        self.customerName = customerName
        self.address = address
        self.email = email
        self.creditCardInfo = creditCardInfo
        self.shippingInfo = shippingInfo
        
    }
    func display() -> String{
        var returnData = ""
        
        if self.customerID != nil{
            returnData += "\n customerID:" + self.customerID!
        }
        if self.customerName != nil{
            returnData +=  "\n customerName:" + self.customerName!
        }
        if self.address != nil{
            returnData +=  "\n address:" + self.address!
        }
        if self.email != nil{
            returnData +=  "\n email:" + self.email!
        }
        if self.creditCardInfo != nil{
            returnData +=  "\n creditCardInfo:" + self.creditCardInfo!
        }
        if self.shippingInfo != nil{
            returnData +=  "\n shippingInfo:" + self.shippingInfo!
        }
         return returnData
    }
    func registerUser(){
        print("enter customerID:")
        self.customerID = readLine()!
        print("enter customerName:")
        self.customerName = readLine()!
        print("enter address:")
        self.address = readLine()!
        print("enter email:")
        self.email = readLine()!
        print("enter creditCardInfo:")
        self.creditCardInfo = readLine()!
        print("enter shippingInfo:")
        self.shippingInfo = readLine()!
        
    }
}
